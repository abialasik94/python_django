from django.contrib import admin
from .models import Film
# Register your models here.

'rejestracja modelu(tabeli), aby był od widoczny z poziomu admina'

admin.site.register(Film)