from django.apps import AppConfig


class ApponlinuxConfig(AppConfig):
    name = 'appOnLinux'
